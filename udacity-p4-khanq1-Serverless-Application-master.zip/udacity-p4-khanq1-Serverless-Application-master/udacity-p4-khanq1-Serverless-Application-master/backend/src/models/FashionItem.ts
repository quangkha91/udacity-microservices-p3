export interface FashionItem {
  userId: string
  fashionId: string
  createdAt: string
  name: string
  description: string
  price: number
  dueDate: string
  done: boolean
  attachmentUrl?: string
}
