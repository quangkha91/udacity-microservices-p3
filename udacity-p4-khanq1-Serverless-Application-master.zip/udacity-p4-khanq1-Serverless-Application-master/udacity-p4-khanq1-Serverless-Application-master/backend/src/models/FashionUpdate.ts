export interface FashionUpdate {
  name: string
  description: string
  price: number
  dueDate: string
  done: boolean
}