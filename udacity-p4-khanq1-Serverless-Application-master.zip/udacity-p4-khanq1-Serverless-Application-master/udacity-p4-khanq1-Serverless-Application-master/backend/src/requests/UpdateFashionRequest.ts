/**
 * Fields in a request to update a single Fashion item.
 */
export interface UpdateFashionRequest {
  name: string
  description: string
  price: number
  dueDate: string
  done: boolean
}