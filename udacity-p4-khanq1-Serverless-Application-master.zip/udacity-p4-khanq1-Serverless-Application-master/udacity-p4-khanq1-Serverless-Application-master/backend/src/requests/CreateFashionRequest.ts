/**
 * Fields in a request to create a single Fashion item.
 */
export interface CreateFashionRequest {
  name: string
  description: string
  price: number
  dueDate: string
}
