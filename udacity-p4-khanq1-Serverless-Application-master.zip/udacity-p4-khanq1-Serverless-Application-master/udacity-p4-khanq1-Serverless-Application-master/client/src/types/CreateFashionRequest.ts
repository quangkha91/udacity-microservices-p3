export interface CreateFashionRequest {
  name: string
  dueDate: string
}
