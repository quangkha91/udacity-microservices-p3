export interface UpdateFashionRequest {
  name: string
  dueDate: string
  done: boolean
}